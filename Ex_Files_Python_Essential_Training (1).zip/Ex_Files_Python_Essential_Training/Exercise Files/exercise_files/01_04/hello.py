
# Print "Hello, World!" to the terminal
print('Hello, World!')